% This is code for Exercise 1 as part of the Hands on with Deep Learning
% and IoT workshop presented at the Grace Hopper Celebration 2018-09-27
%% Connecting to the camera
camera = webcam(1); % Connect to the camera

%% Loading the neural net named: Alexnet
nnet = alexnet; % Load the neural net

%% Capturing and classifying image data
picture = snapshot(camera); % Take a picture
picture = imresize(picture,[227,227]); % Resize the picture
[label,scores] = classify(nnet, picture); % Classify the picture and 
% obtain confidence score
[sorted_scores,indices]=sort(scores,'descend'); % Sorting scores in 
% descending order
image(picture); % Show the picture
title(['Alexnet classification: ',char(label),' score:',...
    num2str(sorted_scores(1))]); % Show the label
clear camera
drawnow;