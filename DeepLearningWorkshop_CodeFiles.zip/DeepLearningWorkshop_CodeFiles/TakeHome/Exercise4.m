% This is take home Exercise 4 as part of the Hands on with Deep Learning
% and IoT workshop presented at the Grace Hopper Celebration 2018-09-27

% In this exercise learn to use the pretrained model GoogLeNet to classify
% images

% Steps to be performed in this exercise:
% 1. Connect to a webcam on your machine
% 2. Load the pretrained model GoogLeNet
% 3. Capture images using your webcam
% 4. Classify the image using GoogLeNet
% 5. Compute the confidence score
% 6. Display the image, name of the object and confidence score

% Hint: https://www.mathworks.com/help/deeplearning/ref/googlenet.html


%% Connecting to the camera
% TODO - Replace [] with code to create webcam object
camera = []; 

%% Loading the neural net named: GoogLeNet
% TODO - Replace [] with the command to load the neural net
nnet = []; % Load the neural net

%% Capturing and classifying image data
% TODO - Replace [] to take a picture using snapshot command
picture = []; 

% Resize the picture
picture = imresize(picture,[224,224]); 

% TODO - Replace [] to classify the picture and obtain confidence score using 'classify' command
[label,scores] = []; 

% Sorting scores in descending order
[sorted_scores,indices]=sort(scores,'descend'); 

% Show the picture
image(picture); 
% Show the label
title(['GoogLeNet classification: ',char(label),' score:',...
    num2str(sorted_scores(1))]); 
clear camera
drawnow;