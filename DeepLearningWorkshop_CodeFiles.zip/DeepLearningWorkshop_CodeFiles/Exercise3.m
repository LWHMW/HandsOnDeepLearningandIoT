% This is code for Exercise 3 as part of the Hands on with Deep Learning
% and IoT workshop presented at the Grace Hopper Celebration 2018-09-27
%% Reading aggregated label data for the last 2 hours from ThingSpeak
readChannelID = 570969;
LabelFieldID = 1;
readAPIKey = '';

dataForLastHours = thingSpeakRead(readChannelID, ...
    'Fields', LabelFieldID,'NumMinutes', 120, ...
    'ReadKey',readAPIKey, 'OutputFormat', 'table');

%% Visualizing data using a histogram
if (not(isempty(dataForLastHours)))
    labelsForLastHours = categorical(dataForLastHours.Label);
    numbins = min(numel(unique(labelsForLastHours)), 20);
    histogram(labelsForLastHours, 'DisplayOrder', 'descend', ...
        'NumDisplayBins', numbins);
    xlabel('Objects Detected');
    ylabel('Number of times detected');
    title('Histogram: Objects Detected by Deep Learning Network');
    set(gca,'FontSize', 10)
end
drawnow